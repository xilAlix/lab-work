﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Variant10.Models;

namespace Variant10.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodProductionsController : ControllerBase
    {
        private readonly ProductContext _context;

        public FoodProductionsController(ProductContext context)
        {
            _context = context;
        }

        // GET: api/FoodProductions
        [HttpGet]
        public async Task<ActionResult<IEnumerable<FoodProduction>>> GetFoodProductions()
        {
            return await _context.FoodProductions.ToListAsync();
        }

        // GET: api/FoodProductions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<FoodProduction>> GetFoodProduction(float id)
        {
            var foodProduction = await _context.FoodProductions.FindAsync(id);

            if (foodProduction == null)
            {
                return NotFound();
            }

            return foodProduction;
        }

        // PUT: api/FoodProductions/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutFoodProduction(float id, FoodProduction foodProduction)
        {
            if (id != foodProduction.productionVolume)
            {
                return BadRequest();
            }

            _context.Entry(foodProduction).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FoodProductionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/FoodProductions
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<FoodProduction>> PostFoodProduction(FoodProduction foodProduction)
        {
            _context.FoodProductions.Add(foodProduction);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (FoodProductionExists(foodProduction.productionVolume))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetFoodProduction", new { id = foodProduction.productionVolume }, foodProduction);
        }

        // DELETE: api/FoodProductions/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFoodProduction(float id)
        {
            var foodProduction = await _context.FoodProductions.FindAsync(id);
            if (foodProduction == null)
            {
                return NotFound();
            }

            _context.FoodProductions.Remove(foodProduction);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool FoodProductionExists(float id)
        {
            return _context.FoodProductions.Any(e => e.productionVolume == id);
        }


        // GET: api/FoodProductions/muchFirms
        [HttpGet("muchFirms")]
        public async Task<IEnumerable<FoodProduction>> GetFrequentFirms()
        {
            var frequentFirmIds = from fp in _context.FoodProductions
                                  group fp by fp.firmId into g
                                  where g.Count() > 3
                                  select g.Key;

            var frequentFirmsProductions = from fp in _context.FoodProductions
                                           where frequentFirmIds.Contains(fp.firmId)
                                           select fp;

            return await frequentFirmsProductions.ToListAsync();
        }
    }
}
