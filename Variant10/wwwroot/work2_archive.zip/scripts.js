// URL к нашим API. Порт (7284) 
const apiUrlProducts = 'https://localhost:7284/api/FoodProducts';
const apiUrlProductions = 'https://localhost:7284/api/FoodProductions';
const apiUrlFirms = 'https://localhost:7284/api/FacturingCompanies';

// Страница продукты питания
async function fetchProducts(request) {
    const loadingDiv = document.getElementById('loading');
    const table = document.getElementById('products-table');
    const errorDiv = document.getElementById('error');
    const tbody = document.getElementById('products-body');
    try {
        // 1. Выполняем GET-запрос к API
        const response = await fetch(request);
        // 2. Проверяем, успешен ли ответ
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        // 3. Парсим JSON-ответ
        const products = await response.json();
        // 4. Скрываем индикатор загрузки
        loadingDiv.style.display = 'none';
        // 5. Если данные есть, заполняем таблицу
        if (products && products.length > 0) {
            table.style.display = 'table'; // Показываем таблицу
            // Очищаем тело таблицы перед заполнением (на случай повторного вызова)
            tbody.innerHTML = '';
            // Перебираем полученный массив абонентов
            products.forEach(product => {
                // Создаем строку таблицы
                const row = document.createElement('tr');
                // Создаем ячейки и заполняем их данными
                // Важно! Названия свойств должны совпадать с названиями столбцов в БД (и в моделях C#)
                row.innerHTML = `
 <td>${product.id}</td>
 <td>${product.title}</td>
 <td>${product.productGroup}</td>
 <td>${product.packageType || 'не указано'}</td> <!-- Если телефон NULL, пишем 'не указан' -->`;
                // Добавляем строку в таблицу
                tbody.appendChild(row);
            });
        } else {
            // Если данных нет, показываем сообщение
            loadingDiv.textContent = 'Нет данных для отображения.';
        }
    } catch (error) {
        // В случае ошибки показываем её
        loadingDiv.style.display = 'none';
        errorDiv.style.display = 'block';
        errorDiv.textContent = `Ошибка при загрузке данных:
${error.message}`;
        console.error('Fetch error:', error);
    }
}

// Страница производство продуктов питания
async function fetchProductions(request) {
    const loadingDiv = document.getElementById('loading');
    const table = document.getElementById('productions-table');
    const errorDiv = document.getElementById('error');
    const tbody = document.getElementById('productions-body');
    try {
        // 1. Выполняем GET-запрос к API
        const response = await fetch(request);
        // 2. Проверяем, успешен ли ответ
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        // 3. Парсим JSON-ответ
        const productions = await response.json();
        // 4. Скрываем индикатор загрузки
        loadingDiv.style.display = 'none';
        // 5. Если данные есть, заполняем таблицу
        if (productions && productions.length > 0) {
            table.style.display = 'table'; // Показываем таблицу
            // Очищаем тело таблицы перед заполнением (на случай повторного вызова)
            tbody.innerHTML = '';
            // Перебираем полученный массив абонентов
            productions.forEach(production => {
                // Создаем строку таблицы
                const row = document.createElement('tr');
                // Создаем ячейки и заполняем их данными
                // Важно! Названия свойств должны совпадать с названиями столбцов в БД (и в моделях C#)
                row.innerHTML = `
 <td>${production.firmId}</td>
 <td>${production.productId}</td>
 <td>${production.productionVolume}</td>`;
                // Добавляем строку в таблицу
                tbody.appendChild(row);
            });
        } else {
            // Если данных нет, показываем сообщение
            loadingDiv.textContent = 'Нет данных для отображения.';
        }
    } catch (error) {
        // В случае ошибки показываем её
        loadingDiv.style.display = 'none';
        errorDiv.style.display = 'block';
        errorDiv.textContent = `Ошибка при загрузке данных:
${error.message}`;
        console.error('Fetch error:', error);
    }
}

// Страница фирмы производители
async function fetchFirms(request) {
    const loadingDiv = document.getElementById('loading');
    const table = document.getElementById('firms-table');
    const errorDiv = document.getElementById('error');
    const tbody = document.getElementById('firms-body');
    try {
        // 1. Выполняем GET-запрос к API
        const response = await fetch(request);
        // 2. Проверяем, успешен ли ответ
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        // 3. Парсим JSON-ответ
        const firms = await response.json();
        // 4. Скрываем индикатор загрузки
        loadingDiv.style.display = 'none';
        // 5. Если данные есть, заполняем таблицу
        if (firms && firms.length > 0) {
            table.style.display = 'table'; // Показываем таблицу
            // Очищаем тело таблицы перед заполнением (на случай повторного вызова)
            tbody.innerHTML = '';
            // Перебираем полученный массив абонентов
            firms.forEach(firm => {
                // Создаем строку таблицы
                const row = document.createElement('tr');
                // Создаем ячейки и заполняем их данными
                // Важно! Названия свойств должны совпадать с названиями столбцов в БД (и в моделях C#)
                row.innerHTML = `
 <td>${firm.firmId}</td>
 <td>${firm.firmName}</td>
 <td>${firm.adress}</td>
 <td>${firm.directorSurname || 'не указано'}</td> <!-- Если телефон NULL, пишем 'не указан' -->`;
                // Добавляем строку в таблицу
                tbody.appendChild(row);
            });
        } else {
            // Если данных нет, показываем сообщение
            loadingDiv.textContent = 'Нет данных для отображения.';
        }
    } catch (error) {
        // В случае ошибки показываем её
        loadingDiv.style.display = 'none';
        errorDiv.style.display = 'block';
        errorDiv.textContent = `Ошибка при загрузке данных:
${error.message}`;
        console.error('Fetch error:', error);
    }
}
